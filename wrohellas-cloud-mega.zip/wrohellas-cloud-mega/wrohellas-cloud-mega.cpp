#include "wrohellas-cloud-mega.h"
#include <Arduino.h>


String ssid = "";
String pass = "";
String wcip = "";
String wccp = "";
String rsid = "";

Stream &esp01 = Serial1;



//        'ERROR;00;',                    // Could not connect to wifi
//        'ERROR;01;',                    // Could connect to cloud server 
//        'ERROR;02;',                    // Error while creating mission
//        'ERROR;03;'                     // Error while finalising mission
char* debug_strings[4] = {'ERROR;00;', 'ERROR;01;', 'ERROR;02;', 'ERROR;03;'};






// Ορισμός σειριακής σύνδεσης του esp και καταχώρηση των στοιχείων σύνδεσης στο wifi
void wifiInit(Stream &init_esp, char* init_ssid, char* init_pass) {
  esp01 = init_esp;
  ssid = init_ssid;
  pass = init_pass;
}

// Ορισμός παραμέτρων cloud
void cloudInit(char*  init_wcip, char*  init_wccp, char* init_rsid) {
  wcip = init_wcip;
  wccp = init_wccp;
  rsid = init_rsid;
}



// Αρχικοποίηση ESP01 και σύνδεση στο διαδίκτυο
void wifiConnect() {
  wifiClear();
  if (wifiConnected() == false) {
    esp01.println("AT+RESTORE");
    delay(3000);
    wifiClear();
    esp01.println("AT+RST");
    delay(2000);
    wifiClear();
    esp01.println("ATE0");
    delay(500);
    esp01.println("AT+CWMODE=1"); 
    delay(500);
    wifiClear();
    esp01.println("AT+CIPMODE=0");
    delay(500);
    //if (rsid != "") {
    //  esp01.println("AT+CWHOSTNAME=\"" + rsid + "\"");
    //  delay(500);
    //}
    wifiClear();
    esp01.println("AT+CIPMUX=0");
    delay(500);
    esp01.println("AT+CWAUTOCONN=1");
    delay(500);
    esp01.println("AT+SLEEP=0");
    delay(500);
    wifiClear();
    esp01.println("AT+CWJAP=\"" + ssid + "\",\"" + pass + "\"");
    delay(5000);
    wifiClear();
  }
}


// Καθαρισμός προσωρινής μνήμης του esp01
void wifiClear() {
  while (esp01.available()) {
    int inbyte = esp01.read();
  }
}


// Καθαρισμός προσωρινής μνήμης του esp01 μέχρι τον χαρακτήρα για x φορές
void wifiClearUntil(char ch, int x) {
  for (int i = 0; i < x; i++) {
    String tmp = esp01.readStringUntil(ch);
    tmp = "";
  }
}


// Έλεγχος σύνδεσης στο δίκτυο
bool wifiConnected() {
  delay(1000);
  wifiClear();
  esp01.println("AT+CIFSR");
  delay(1000);
  String buf;
  while (esp01.available()) {
    buf += esp01.readString();
  }
  wifiClear();
  if ((buf.indexOf("CIFSR:STAIP")>0) && (buf.indexOf("0.0.0.0")<0)) {
    return true;
  } else {
    return false;
  }
  //Serial.print(buf);
  //int pos = buf.indexOf(":"); 
  //if (pos >0) {
  //  if (buf.charAt(pos+1) == "5") {return false;} else {return true;}
  //} else {
  //  return false;
  //}
}






// Δημιουργία αποστολής
String createMission(String missionType) {
  delay(1000);
  if (!wifiConnected()) {
    return debug_strings[0];
  } else {
    String buf = rsid + ";" + missionType + ";";
    int bufLength = buf.length();
    wifiClear();
    esp01.println("AT+CIPSTART=\"TCP\",\"" + wcip + "\"," + wccp);
    delay(1000);
    if (wifiResponse()) {
      wifiClear();
      esp01.println("AT+CIPSEND=" + String(bufLength+2));
      delay(500);
      wifiClear();
      esp01.println(buf);
      //delay(200);
      //wifiClear(esp01);
      //delay(1500);
      delay(200);
      wifiClearUntil(':', 1);
      String rawData = wifiRawResponse();
      esp01.println("AT+CIPCLOSE");
      delay(1000);
      wifiClear();
      if (rawData == "") {
        return debug_strings[2];
      } else {
        return rawData;
      }
    } else {
      return debug_strings[1];
    }
  }
}


// Ολοκλήρωση αποστολής
String completeMission(String mID, String data) {
  delay(1000);
  if (!wifiConnected()) {
    return debug_strings[0];
  } else {  
    String buf = mID + ";" + data + ";";
    int bufLength = buf.length();
    wifiClear();
    esp01.println("AT+CIPSTART=\"TCP\",\"" + wcip + "\"," + wccp);
    delay(1000);
    if (wifiResponse()) {
      wifiClear();
      esp01.println("AT+CIPSEND=" + String(bufLength+2));
      delay(500);
      wifiClear();
      esp01.println(buf);
      delay(200);
      wifiClearUntil(':', 1);
      String rawData = wifiRawResponse();
      esp01.println("AT+CIPCLOSE");
      delay(1000);
      wifiClear();
      if (rawData == "") {
        return debug_strings[3];
      } else {
        return rawData;
      }
    } else {
      return debug_strings[1];
    }
  }
}


// ελεγχος απόκρισης στην προσωρινή μνήμη
bool wifiResponse() {
  String buf;
  while (esp01.available()) {
    buf += esp01.readString();
  }
  //Serial.println(buf);
  if ((buf.indexOf("OK")>0) or (buf.indexOf("CONNECTED")>0) or (buf.indexOf("CONNECT")>0)) {
    return true;
  } else {
    return false;
  }
}


// Λήψη περιεχομένου μνήμης εισερχόμενων του esp01
String wifiRawResponse() {
  String buf;
  while (esp01.available()) {
    buf += esp01.readString();
  }
  return buf;
}


