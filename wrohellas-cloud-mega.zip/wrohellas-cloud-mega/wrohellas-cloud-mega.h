#ifndef WROHELLAS-CLOUD-MEGA_H
#define WROHELLAS-CLOUD-MEGA_H

#include <Arduino.h>

// Ορισμός σειριακής σύνδεσης του esp και καταχώρηση των στοιχείων σύνδεσης στο wifi
void wifiInit(Stream &init_esp, char* init_ssid, char* init_pass);

// Ορισμός παραμέτρων cloud
void cloudInit(char*  init_wcip, char*  init_wccp, char* init_rsid);

// Αρχικοποίηση ESP01 και σύνδεση στο διαδίκτυο
void wifiConnect();

// Καθαρισμός προσωρινής μνήμης του esp01
void wifiClear();

// Καθαρισμός προσωρινής μνήμης του esp01 μέχρι τον χαρακτήρα για x φορές
void wifiClearUntil(char ch, int x);

// Έλεγχος σύνδεσης στο δίκτυο
bool wifiConnected();

// Δημιουργία αποστολής
String createMission(String missionType);

// Ολοκλήρωση αποστολής
String completeMission(String mID, String data);

// ελεγχος απόκρισης στην προσωρινή μνήμη
bool wifiResponse();

// Λήψη περιεχομένου μνήμης εισερχόμενων του esp01
String wifiRawResponse();

#endif
